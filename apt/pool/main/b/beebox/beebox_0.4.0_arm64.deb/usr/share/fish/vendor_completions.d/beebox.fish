# fish completion for beebox
complete -c beebox -f
complete -c beebox -n __fish_use_subcommand -a completion -d "Print a shell completion script (bash, zsh, fish)"
complete -c beebox -n __fish_use_subcommand -a notify -d "Tell the logged-in user about a new crash report"
complete -c beebox -n '__fish_seen_subcommand_from notify' -l wait
complete -c beebox -n '__fish_seen_subcommand_from notify' -l test
complete -c beebox -n __fish_use_subcommand -a last -d "Show the most recent crash report"
complete -c beebox -n '__fish_seen_subcommand_from last' -l json
complete -c beebox -n '__fish_seen_subcommand_from last' -l verbose
complete -c beebox -n '__fish_seen_subcommand_from last' -l html -r -F
complete -c beebox -n __fish_use_subcommand -a show -d "Show one report (default: the latest)"
complete -c beebox -n '__fish_seen_subcommand_from show' -l json
complete -c beebox -n '__fish_seen_subcommand_from show' -l verbose
complete -c beebox -n '__fish_seen_subcommand_from show' -l html -r -F
complete -c beebox -n __fish_use_subcommand -a list -d "List crash reports, newest first"
complete -c beebox -n '__fish_seen_subcommand_from list' -l json
complete -c beebox -n '__fish_seen_subcommand_from list' -l ids
complete -c beebox -n __fish_use_subcommand -a view -d "Open a report in your web browser"
complete -c beebox -n '__fish_seen_subcommand_from view' -l print-path
complete -c beebox -n '__fish_seen_subcommand_from view' -l sample
complete -c beebox -n '__fish_seen_subcommand_from view' -l scenario
complete -c beebox -n __fish_use_subcommand -a analyze -d "Work out why a previous boot ended"
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l boot
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l ring -r -F
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l save
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l json
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l verbose
complete -c beebox -n '__fish_seen_subcommand_from analyze' -l html -r -F
complete -c beebox -n __fish_use_subcommand -a status -d "Check that BeeBox is recording"
complete -c beebox -n '__fish_seen_subcommand_from status' -l json
complete -c beebox -n __fish_use_subcommand -a now -d "Show what BeeBox is measuring right now"
complete -c beebox -n '__fish_seen_subcommand_from now' -l watch
complete -c beebox -n '__fish_seen_subcommand_from now' -l json
complete -c beebox -n __fish_use_subcommand -a doctor -d "Check this computer is ready to catch the next crash"
complete -c beebox -n '__fish_seen_subcommand_from doctor' -l json
complete -c beebox -n '__fish_seen_subcommand_from doctor' -l strict
complete -c beebox -n __fish_use_subcommand -a setup -d "Switch on everything BeeBox needs to catch the next crash"
complete -c beebox -n '__fish_seen_subcommand_from setup' -l yes
complete -c beebox -n '__fish_seen_subcommand_from setup' -l dry-run
complete -c beebox -n '__fish_seen_subcommand_from setup' -l skip
complete -c beebox -n __fish_use_subcommand -a record -d "Run the recorder (started for you by systemd)"
complete -c beebox -n '__fish_seen_subcommand_from record' -l config -r -F
complete -c beebox -n __fish_use_subcommand -a version -d "Print the version"
complete -c beebox -n '__fish_seen_subcommand_from version' -l verbose
complete -c beebox -n '__fish_seen_subcommand_from version' -l json
complete -c beebox -n __fish_use_subcommand -a help -d "Show help for beebox or a command"
complete -c beebox -n '__fish_seen_subcommand_from show view' -a '(beebox list --ids 2>/dev/null)'
complete -c beebox -n '__fish_seen_subcommand_from completion' -a 'bash zsh fish'
complete -c beebox -l plain -d 'No colour or graphics'
complete -c beebox -l no-color -d 'No colour'
complete -c beebox -l no-banner -d 'No banner'
